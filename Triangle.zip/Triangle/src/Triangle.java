import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Triangle extends JPanel {
    private boolean isTriangle = true; // Track whether the shape is a triangle or square

    public Triangle() {
        // Add a mouse listener to handle clicks
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                // Toggle the shape on mouse click
                isTriangle = !isTriangle;
                repaint(); // Repaint the panel to update the shape
            }
        });
    }
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        // Set background color
        setBackground(Color.BLACK);
        
        // Set color for the shape
        g.setColor(Color.BLUE);
        
        if (isTriangle) {
            // Define the triangle points
            int[] xPoints = {170, 120, 220}; // X coordinates
            int[] yPoints = {80, 180, 180};   // Y coordinates
            g.fillPolygon(xPoints, yPoints, 3); // Draw filled triangle
        } else {
            // Draw a square
            g.fillRect(120, 80, 100, 100); // Draw filled square (x, y, width, height)
        }
        
        // Set color for the text
        g.setColor(Color.WHITE); // Change text color to white for visibility
        g.setFont(new Font("Arial", Font.PLAIN, 24));
        
        // Draw "Hello World" text below the shape
        g.drawString("Hello World", 110, 210); // Adjusted y-coordinate to position below the shape
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Triangle with Hello World");
        Triangle panel = new Triangle();
        
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(panel);
        frame.setSize(400, 300);
        frame.setVisible(true);
        frame.setLocationRelativeTo(null); // Center the frame on the screen
    }
}